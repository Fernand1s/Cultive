package br.com.cultiva.cultivamais.multitenant;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface EmpresaRepository extends JpaRepository<Empresa, UUID> {

    Optional<Empresa> findBySchemaName(String schemaName);

    Optional<Empresa> findByNome(String nome);

    // Busca a empresa pelo email de um usuário dentro do schema public
    // Isso é necessário no login para descobrir qual schema usar
    @Query(value = """
        SELECT e.* FROM public.empresa e
        WHERE e.schema_name = (
            SELECT schema_name FROM public.empresa_usuario_index
            WHERE email = :email
        )
        """, nativeQuery = true)
    Optional<Empresa> findByEmailUsuario(@Param("email") String email);
}