package br.com.cultiva.cultivamais.multitenant;

import br.com.cultiva.cultivamais.multitenant.UsuarioRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;

@Component
public class SecurityFilter extends OncePerRequestFilter {

    private final UsuarioRepository usuarioRepository;
    private final JwtService jwtService;           // <-- injeta o service
    private final EmpresaRepository empresaRepository;

    public SecurityFilter(UsuarioRepository usuarioRepository,
                          JwtService jwtService,
                          EmpresaRepository empresaRepository) {
        this.usuarioRepository = usuarioRepository;
        this.jwtService = jwtService;
        this.empresaRepository = empresaRepository;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {
        try {
            String token = recuperarToken(request);

            if (token != null && jwtService.isTokenValid(token)) {

                // 1. Define o schema na thread ANTES de qualquer query
                String schema = jwtService.extractSchemaName(token);
                if (schema != null) {
                    TenantContext.setTenant(schema);
                }

                // 2. Autentica o usuário normalmente
                String email = jwtService.extractEmail(token);
                var usuario = usuarioRepository.findByEmail(email).orElse(null);

                if (usuario != null) {
                    var authorities = Collections.singletonList(
                            new SimpleGrantedAuthority("ROLE_" + usuario.getFuncao().name())
                    );
                    var authentication = new UsernamePasswordAuthenticationToken(
                            usuario, null, authorities
                    );
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                }
            }

            filterChain.doFilter(request, response);

        } finally {
            TenantContext.clear(); // Sempre limpa ao final
        }
    }

    private String recuperarToken(HttpServletRequest request) {
        var authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) return null;
        return authHeader.replace("Bearer ", "");
    }
}
