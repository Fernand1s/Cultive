package br.com.cultiva.cultivamais.multitenant;

import br.com.cultiva.cultivamais.multitenant.Usuario;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.function.Function;

@Service
public class JwtService {

    // A MESMA chave do seu SecurityFilter — centralizando aqui
    private static final String SECRET_KEY = "ProjetoCultivaMais_Sustentavel_2026_Seguranca_Total";

    // -------------------------------------------------------
    // GERAÇÃO DO TOKEN (agora com schemaName)
    // -------------------------------------------------------
    public String generateToken(Usuario usuario, String schemaName) {
        return Jwts.builder()
                .setSubject(usuario.getEmail())
                .claim("idUsuario", usuario.getIdUsuario())
                .claim("funcao", usuario.getFuncao().name())
                .claim("schemaName", schemaName)         // <-- multi-tenant
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 86400000)) // 24h
                .signWith(getSignKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    // -------------------------------------------------------
    // EXTRAÇÕES
    // -------------------------------------------------------
    public String extractEmail(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public String extractSchemaName(String token) {
        return extractClaim(token, claims -> claims.get("schemaName", String.class));
    }

    public String extractFuncao(String token) {
        return extractClaim(token, claims -> claims.get("funcao", String.class));
    }

    public Long extractIdUsuario(String token) {
        return extractClaim(token, claims -> claims.get("idUsuario", Long.class));
    }

    public boolean isTokenValid(String token) {
        try {
            return !isTokenExpired(token);
        } catch (Exception e) {
            return false;
        }
    }

    // -------------------------------------------------------
    // MÉTODOS PRIVADOS AUXILIARES
    // -------------------------------------------------------
    private boolean isTokenExpired(String token) {
        return extractClaim(token, Claims::getExpiration).before(new Date());
    }

    // Esse era o método que estava faltando e causava os erros
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    private Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSignKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    // Esse era o outro método que estava faltando
    private Key getSignKey() {
        return Keys.hmacShaKeyFor(SECRET_KEY.getBytes());
    }
}