package br.com.cultiva.cultivamais.multitenant;

// TenantContext.java
public class TenantContext {

    private static final ThreadLocal<String> CURRENT_TENANT = new ThreadLocal<>();

    public static void setTenant(String schemaName) {
        CURRENT_TENANT.set(schemaName);
    }

    public static String getTenant() {
        return CURRENT_TENANT.get();
    }

    public static void clear() {
        CURRENT_TENANT.remove();
    }
}
