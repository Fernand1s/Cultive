package br.com.cultiva.cultivamais.multitenant;



import java.util.List;
import java.util.UUID;

import br.com.cultiva.cultivamais.service.LogService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.cultiva.cultivamais.exception.ResourceNotFoundException;
import io.micrometer.common.lang.NonNull;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final LogService logService;
    private final PasswordEncoder passwordEncoder;
    //private final NotificacaoService notificacaoService;
    private final JdbcTemplate jdbcTemplate; // <-- NOVO

    public UsuarioService(UsuarioRepository usuarioRepository,
                          LogService logService,
                          PasswordEncoder passwordEncoder,
                          //NotificacaoService notificacaoService,
                          JdbcTemplate jdbcTemplate) {
        this.usuarioRepository = usuarioRepository;
        this.logService = logService;
        this.passwordEncoder = passwordEncoder;
        //this.notificacaoService = notificacaoService;
        this.jdbcTemplate = jdbcTemplate;
    }

    // BUSCAR POR ID — sem alteração
    public Usuario buscarPorId(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Usuário não encontrado com ID: " + id));
    }

    // CRIAR USUÁRIO — adicionado o insert no índice público
    @Transactional
    public Usuario criarUsuario(@NonNull Usuario novoUsuario) {
        try {
            novoUsuario.setSenha(passwordEncoder.encode(novoUsuario.getSenha()));

            if (novoUsuario.getAtivo() == null) {
                novoUsuario.setAtivo(true);
            }

            Usuario usuarioSalvo = usuarioRepository.save(novoUsuario);

            // --------------------------------------------------------
            // NOVO: indexa o email no schema public para que o login
            // consiga resolver o tenant sem ter um token ainda
            // --------------------------------------------------------
            String schemaAtual = TenantContext.getTenant();
            if (schemaAtual != null && !schemaAtual.isBlank()) {
                jdbcTemplate.update(
                        "INSERT INTO public.empresa_usuario_index (email, schema_name) " +
                                "VALUES (?, ?) ON CONFLICT (email) DO NOTHING",
                        usuarioSalvo.getEmail(),
                        schemaAtual
                );
            }
            // --------------------------------------------------------

            logService.registrarLog("SISTEMA",
                    "Criou novo usuário: " + usuarioSalvo.getNomeUsuario());

            try {

                notificarAdministradores(
                        "Novo Cadastro no Sistema",
                        "O usuário " + usuarioSalvo.getNomeUsuario()
                                + " registrado como " + usuarioSalvo.getFuncao(),
                        "info"
                );
            } catch (Exception e) {
                System.err.println("Erro ao processar notificações: " + e.getMessage());
            }

            return usuarioSalvo;

        } catch (DataIntegrityViolationException e) {
            throw new RuntimeException(
                    "Erro: O e-mail informado já está cadastrado no sistema.");
        }
    }

    // LISTAR TODOS — sem alteração
    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll();
    }

    // ATUALIZAR USUÁRIO — sem alteração
    @Transactional
    public Usuario atualizarUsuario(Long id, Usuario dadosAtualizados) {
        Usuario usuario = buscarPorId(id);
        boolean senhaAlterada = false;

        if (dadosAtualizados.getNomeUsuario() != null
                && !dadosAtualizados.getNomeUsuario().isBlank()) {
            usuario.setNomeUsuario(dadosAtualizados.getNomeUsuario());
        }
        if (dadosAtualizados.getEmail() != null
                && !dadosAtualizados.getEmail().isBlank()) {
            usuario.setEmail(dadosAtualizados.getEmail());
        }
        if (dadosAtualizados.getFuncao() != null) {
            usuario.setFuncao(dadosAtualizados.getFuncao());
        }
        if (dadosAtualizados.getAtivo() != null) {
            usuario.setAtivo(dadosAtualizados.getAtivo());
        }
        if (dadosAtualizados.getSenha() != null
                && !dadosAtualizados.getSenha().isBlank()) {
            usuario.setSenha(passwordEncoder.encode(dadosAtualizados.getSenha()));
            senhaAlterada = true;
        }

        Usuario salvo = usuarioRepository.save(usuario);



        return salvo;
    }

    // EXCLUIR USUÁRIO — remove também do índice público
    @Transactional
    public void excluirUsuario(@NonNull Long id) {
        Usuario usuario = buscarPorId(id);

        // Remove do índice público para não deixar email órfão
        jdbcTemplate.update(
                "DELETE FROM public.empresa_usuario_index WHERE email = ?",
                usuario.getEmail()
        );

        usuarioRepository.deleteById(id);
    }

    // AUTENTICAR — sem alteração
    public Usuario autenticar(String email, String senhaPlana) {
        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        if (passwordEncoder.matches(senhaPlana, usuario.getSenha())
                && Boolean.TRUE.equals(usuario.getAtivo())) {
            logService.registrarLog(usuario.getNomeUsuario(), "Realizou Login");
            return usuario;
        }
        return null;
    }

    // GERAR CÓDIGO — sem alteração
    @Transactional
    public String gerarCodigoRecuperacao(String email) {
        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        String codigo = UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        usuario.setCodigoRecuperacao(codigo);
        usuarioRepository.save(usuario);
        return codigo;
    }

    // REDEFINIR SENHA — sem alteração
    @Transactional
    public boolean redefinirSenhaComCodigo(String email, String codigoInput,
                                           String novaSenha) {
        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        if (usuario.getCodigoRecuperacao() != null
                && usuario.getCodigoRecuperacao().equals(codigoInput)) {
            usuario.setSenha(passwordEncoder.encode(novaSenha));
            usuario.setCodigoRecuperacao(null);
            usuarioRepository.save(usuario);
            logService.registrarLog(email, "Redefiniu a senha com sucesso via código.");
            return true;
        }
        return false;
    }

    // AUXILIAR — sem alteração
    private void notificarAdministradores(String titulo, String mensagem, String tipo) {
        usuarioRepository.findAll().stream()
                .filter(u -> u.getFuncao() != null)
                .filter(u -> u.getFuncao().name().toUpperCase().contains("ADMIN")
                        || u.getFuncao().name().toUpperCase().contains("EMPRESA"));
    }
}