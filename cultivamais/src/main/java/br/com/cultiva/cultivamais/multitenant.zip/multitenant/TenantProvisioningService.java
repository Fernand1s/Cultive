package br.com.cultiva.cultivamais.multitenant;

import br.com.cultiva.cultivamais.multitenant.Empresa;
import br.com.cultiva.cultivamais.multitenant.EmpresaRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class TenantProvisioningService {

    private final JdbcTemplate jdbcTemplate;
    private final EmpresaRepository empresaRepository;

    public TenantProvisioningService(JdbcTemplate jdbcTemplate,
                                     EmpresaRepository empresaRepository) {
        this.jdbcTemplate = jdbcTemplate;
        this.empresaRepository = empresaRepository;
    }

    // ----------------------------------------------------------------
    // PROVISIONAR NOVA EMPRESA — cria schema + tabelas + salva no master
    // Chamado apenas pelo seu painel interno quando fechar contrato
    // ----------------------------------------------------------------
    @Transactional
    public Empresa provisionarNovoTenant(String nomeEmpresa, String emailAdmin) {

        // 1. Gera nome de schema seguro e único
        String schemaBase = nomeEmpresa
                .toLowerCase()
                .trim()
                .replaceAll("[^a-z0-9]", "_");   // só letras, números e _

        String schemaName = "tenant_" + schemaBase
                + "_" + UUID.randomUUID().toString().replace("-", "").substring(0, 6);

        // 2. Cria o schema no PostgreSQL
        jdbcTemplate.execute(
                "CREATE SCHEMA IF NOT EXISTS \"" + schemaName + "\""
        );

        // 3. Cria todas as tabelas dentro do novo schema
        criarTabelasNoSchema(schemaName);

        // 4. Registra no índice público o email do admin
        // (outros usuários serão indexados ao ser criados via UsuarioService)
        jdbcTemplate.update(
                "INSERT INTO public.empresa_usuario_index (email, schema_name) VALUES (?, ?)",
                emailAdmin, schemaName
        );

        // 5. Persiste a empresa na tabela master (schema public)
        Empresa empresa = new Empresa(nomeEmpresa, schemaName);
        return empresaRepository.save(empresa);
    }

    // ----------------------------------------------------------------
    // REMOVER TENANT — use com extrema cautela (irreversível)
    // ----------------------------------------------------------------
    @Transactional
    public void removerTenant(String schemaName) {

        // Valida que o schema existe antes de tentar remover
        empresaRepository.findBySchemaName(schemaName)
                .orElseThrow(() -> new RuntimeException(
                        "Schema não encontrado: " + schemaName));

        // Remove todos os índices de email deste tenant
        jdbcTemplate.update(
                "DELETE FROM public.empresa_usuario_index WHERE schema_name = ?",
                schemaName
        );

        // Remove o registro master
        jdbcTemplate.update(
                "DELETE FROM public.empresa WHERE schema_name = ?",
                schemaName
        );

        // Derruba o schema inteiro com todos os dados
        jdbcTemplate.execute(
                "DROP SCHEMA IF EXISTS \"" + schemaName + "\" CASCADE"
        );
    }

    // ----------------------------------------------------------------
    // DDL — cria as tabelas dentro do schema recém-criado
    // Espelha exatamente a estrutura atual do seu sistema
    // ----------------------------------------------------------------
    private void criarTabelasNoSchema(String schema) {

        // Aponta para o schema correto nesta conexão
        jdbcTemplate.execute("SET search_path TO \"" + schema + "\"");

        // -- USUÁRIO --------------------------------------------------
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS usuario (
                id_usuario          BIGSERIAL PRIMARY KEY,
                nome_usuario        VARCHAR(255) NOT NULL,
                email               VARCHAR(255) NOT NULL UNIQUE,
                senha               VARCHAR(255) NOT NULL,
                funcao              VARCHAR(50),
                ativo               BOOLEAN DEFAULT TRUE,
                codigo_recuperacao  VARCHAR(20)
            )
        """);

        // -- TAREFA ---------------------------------------------------
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS tarefa (
                id_tarefa       BIGSERIAL PRIMARY KEY,
                titulo          VARCHAR(255),
                descricao       TEXT,
                status          VARCHAR(50),
                data_criacao    TIMESTAMP DEFAULT NOW(),
                data_conclusao  TIMESTAMP,
                responsavel_id  BIGINT REFERENCES usuario(id_usuario) ON DELETE SET NULL,
                criador_id      BIGINT REFERENCES usuario(id_usuario) ON DELETE SET NULL
            )
        """);

        // -- NOTIFICAÇÃO ----------------------------------------------
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS notificacao (
                id_notificacao  BIGSERIAL PRIMARY KEY,
                titulo          VARCHAR(255),
                mensagem        TEXT,
                tipo            VARCHAR(50),
                lida            BOOLEAN DEFAULT FALSE,
                criada_em       TIMESTAMP DEFAULT NOW(),
                usuario_id      BIGINT REFERENCES usuario(id_usuario) ON DELETE CASCADE
            )
        """);

        // -- TERRA ----------------------------------------------------
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS terra (
                id_terra        BIGSERIAL PRIMARY KEY,
                nome            VARCHAR(255) NOT NULL,
                area_hectares   NUMERIC(10, 2),
                descricao       TEXT,
                ativa           BOOLEAN DEFAULT TRUE
            )
        """);

        // -- PLANTA ---------------------------------------------------
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS planta (
                id_planta       BIGSERIAL PRIMARY KEY,
                nome_comum      VARCHAR(255) NOT NULL,
                nome_cientifico VARCHAR(255),
                descricao       TEXT
            )
        """);

        // -- CULTIVO --------------------------------------------------
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS cultivo (
                id_cultivo      BIGSERIAL PRIMARY KEY,
                data_plantio    DATE,
                data_colheita   DATE,
                status          VARCHAR(50),
                observacoes     TEXT,
                terra_id        BIGINT REFERENCES terra(id_terra) ON DELETE SET NULL,
                planta_id       BIGINT REFERENCES planta(id_planta) ON DELETE SET NULL,
                responsavel_id  BIGINT REFERENCES usuario(id_usuario) ON DELETE SET NULL
            )
        """);

        // -- LOG DE AUDITORIA ----------------------------------------
        jdbcTemplate.execute("""
            CREATE TABLE IF NOT EXISTS log_auditoria (
                id_log          BIGSERIAL PRIMARY KEY,
                operador        VARCHAR(255),
                acao            TEXT,
                data_hora       TIMESTAMP DEFAULT NOW()
            )
        """);

        // Restaura para public ao terminar
        jdbcTemplate.execute("SET search_path TO public");
    }
}