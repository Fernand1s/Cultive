package br.com.cultiva.cultivamais.multitenant;

import java.util.List;
import java.util.Map;

import br.com.cultiva.cultivamais.security.SecurityUtils;
import br.com.cultiva.cultivamais.multitenant.JwtService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import br.com.cultiva.cultivamais.multitenant.UsuarioCadastroDTO;
import br.com.cultiva.cultivamais.multitenant.UsuarioUpdateDTO;
import br.com.cultiva.cultivamais.dto.LoginRequest;
import br.com.cultiva.cultivamais.multitenant.Usuario;
import br.com.cultiva.cultivamais.service.LogService;
import br.com.cultiva.cultivamais.multitenant.UsuarioService;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    private final UsuarioService usuarioService;
    private final LogService logService;
    private final JwtService jwtService;
    private final SecurityUtils securityUtils;
    private final EmpresaRepository empresaRepository; // <-- NOVO

    public UsuarioController(UsuarioService usuarioService,
                             LogService logService,
                             JwtService jwtService,
                             SecurityUtils securityUtils,
                             EmpresaRepository empresaRepository) {
        this.usuarioService = usuarioService;
        this.logService = logService;
        this.jwtService = jwtService;
        this.securityUtils = securityUtils;
        this.empresaRepository = empresaRepository;
    }

    // ----------------------------------------------------------------
    // BUSCAR USUÁRIO POR ID
    // ----------------------------------------------------------------
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> buscar(@PathVariable Long id) {
        Usuario usuario = usuarioService.buscarPorId(id);
        usuario.setSenha(null);
        return ResponseEntity.ok(usuario);
    }

    // ----------------------------------------------------------------
    // CRIAR NOVO USUÁRIO
    // O TenantContext já estará definido pelo SecurityFilter neste ponto,
    // pois apenas usuários autenticados (com token) chegam aqui.
    // ----------------------------------------------------------------
    @PostMapping
    public ResponseEntity<Usuario> criar(@Valid @RequestBody UsuarioCadastroDTO dto) {
        Usuario u = new Usuario();
        u.setNomeUsuario(dto.getNomeUsuario());
        u.setEmail(dto.getEmail());
        u.setSenha(dto.getSenha());
        u.setFuncao(dto.getFuncao());

        // criarUsuario já insere na empresa_usuario_index internamente
        Usuario salvo = usuarioService.criarUsuario(u);
        salvo.setSenha(null);
        return ResponseEntity.status(HttpStatus.CREATED).body(salvo);
    }

    // ----------------------------------------------------------------
    // LISTAR TODOS OS USUÁRIOS
    // ----------------------------------------------------------------
    @GetMapping
    public ResponseEntity<List<Usuario>> listar() {
        List<Usuario> usuarios = usuarioService.listarTodos();
        usuarios.forEach(u -> u.setSenha(null));
        return ResponseEntity.ok(usuarios);
    }

    // ----------------------------------------------------------------
    // ATUALIZAR USUÁRIO
    // ----------------------------------------------------------------
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> atualizar(
            @PathVariable Long id,
            @Valid @RequestBody UsuarioUpdateDTO dto) {

        Usuario antigo = usuarioService.buscarPorId(id);
        boolean eraAtivo = antigo.getAtivo();

        Usuario dadosParaAtualizar = new Usuario();
        dadosParaAtualizar.setNomeUsuario(dto.getNomeUsuario());
        dadosParaAtualizar.setEmail(dto.getEmail());
        dadosParaAtualizar.setFuncao(dto.getFuncao());
        dadosParaAtualizar.setAtivo(dto.getAtivo());

        Usuario atualizado = usuarioService.atualizarUsuario(id, dadosParaAtualizar);

        String operador = securityUtils.getNomeUsuarioLogado();
        String acao = "Editou usuário " + atualizado.getNomeUsuario();

        if (eraAtivo && !atualizado.getAtivo()) {
            acao = "Bloqueou usuário " + atualizado.getNomeUsuario();
        } else if (!eraAtivo && atualizado.getAtivo()) {
            acao = "Desbloqueou usuário " + atualizado.getNomeUsuario();
        }

        logService.registrarLog(operador, acao);
        atualizado.setSenha(null);
        return ResponseEntity.ok(atualizado);
    }

    // ----------------------------------------------------------------
    // EXCLUIR USUÁRIO
    // ----------------------------------------------------------------
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        Usuario alvo = usuarioService.buscarPorId(id);
        usuarioService.excluirUsuario(id);

        logService.registrarLog(securityUtils.getNomeUsuarioLogado(),
                "Excluiu usuário permanentemente: " + alvo.getNomeUsuario());

        return ResponseEntity.noContent().build();
    }

    // ----------------------------------------------------------------
    // LOGIN — ponto mais crítico: resolve o schema ANTES de autenticar
    // ----------------------------------------------------------------
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {

        // PASSO 1: Busca a empresa pelo email no índice público
        // Sem isso, o Hibernate não sabe em qual schema procurar o usuário
        Empresa empresa = empresaRepository
                .findByEmailUsuario(req.getEmail())
                .orElse(null);

        if (empresa == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Nenhuma empresa encontrada para este e-mail.");
        }

        if (!empresa.getAtivo()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("A empresa associada a este usuário está inativa.");
        }

        // PASSO 2: Define o schema correto na thread atual
        // A partir daqui, TODAS as queries do Hibernate irão para este schema
        TenantContext.setTenant(empresa.getSchemaName());

        try {
            // PASSO 3: Autentica normalmente (agora no schema certo)
            Usuario logado = usuarioService.autenticar(req.getEmail(), req.getSenha());

            if (logado == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body("E-mail ou senha inválidos.");
            }

            // PASSO 4: Gera token JWTcom schemaName embutido
            String token = jwtService.generateToken(logado, empresa.getSchemaName());

            return ResponseEntity.ok(Map.of(
                    "token",       token,
                    "idUsuario",   logado.getIdUsuario(),
                    "nomeUsuario", logado.getNomeUsuario(),
                    "funcao",      logado.getFuncao(),
                    "email",       logado.getEmail(),
                    "ativo",       logado.getAtivo(),
                    "empresa",     empresa.getNome()  // útil no front para exibição
            ));

        } finally {
            // PASSO 5: Limpa o contexto — o SecurityFilter vai redefinir
            // na próxima requisição autenticada via token
            TenantContext.clear();
        }
    }

    // ----------------------------------------------------------------
    // GERAR CÓDIGO DE RECUPERAÇÃO
    // Também precisa resolver o schema, pois o usuário não tem token ainda
    // ----------------------------------------------------------------
    @PostMapping("/gerar-codigo")
    public ResponseEntity<Map<String, String>> gerarCodigo(
            @RequestBody Map<String, String> payload) {

        String email = payload.get("email");

        // Mesmo problema do login: precisa do schema antes de buscar o usuário
        Empresa empresa = empresaRepository
                .findByEmailUsuario(email)
                .orElse(null);

        if (empresa == null) {
            return ResponseEntity.badRequest().build();
        }

        TenantContext.setTenant(empresa.getSchemaName());
        try {
            String codigo = usuarioService.gerarCodigoRecuperacao(email);
            return codigo != null
                    ? ResponseEntity.ok(Map.of("codigo", codigo))
                    : ResponseEntity.badRequest().build();
        } finally {
            TenantContext.clear();
        }
    }

    // ----------------------------------------------------------------
    // REDEFINIR SENHA — mesma lógica de resolução de schema
    // ----------------------------------------------------------------
    @PostMapping("/redefinir-senha")
    public ResponseEntity<Void> redefinir(@RequestBody Map<String, String> payload) {

        String email = payload.get("email");

        Empresa empresa = empresaRepository
                .findByEmailUsuario(email)
                .orElse(null);

        if (empresa == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        TenantContext.setTenant(empresa.getSchemaName());
        try {
            boolean sucesso = usuarioService.redefinirSenhaComCodigo(
                    email,
                    payload.get("codigo"),
                    payload.get("novaSenha")
            );
            return sucesso
                    ? ResponseEntity.ok().build()
                    : ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        } finally {
            TenantContext.clear();
        }
    }
}