package br.com.cultiva.cultivamais.multitenant;

import br.com.cultiva.cultivamais.multitenant.Empresa;
import br.com.cultiva.cultivamais.multitenant.TenantProvisioningService;
import br.com.cultiva.cultivamais.multitenant.EmpresaRepository;
import br.com.cultiva.cultivamais.service.LogService;
import br.com.cultiva.cultivamais.security.SecurityUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/empresas")
public class EmpresaController {

    private final TenantProvisioningService provisioningService;
    private final EmpresaRepository empresaRepository;
    private final LogService logService;
    private final SecurityUtils securityUtils;

    public EmpresaController(TenantProvisioningService provisioningService,
                             EmpresaRepository empresaRepository,
                             LogService logService,
                             SecurityUtils securityUtils) {
        this.provisioningService = provisioningService;
        this.empresaRepository = empresaRepository;
        this.logService = logService;
        this.securityUtils = securityUtils;
    }

    // ----------------------------------------------------------------
    // CADASTRAR NOVA EMPRESA — provisiona schema + tabelas completas
    // Apenas usuários com role MASTER (seu painel interno) acessam
    // ----------------------------------------------------------------
    @PostMapping
    @PreAuthorize("hasRole('MASTER')")
    public ResponseEntity<?> cadastrar(@Valid @RequestBody CadastroEmpresaRequest req) {

        // Verifica se já existe empresa com o mesmo nome
        if (empresaRepository.findByNome(req.getNomeEmpresa()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("erro", "Já existe uma empresa cadastrada com este nome."));
        }

        try {
            Empresa empresa = provisioningService.provisionarNovoTenant(
                    req.getNomeEmpresa(),
                    req.getEmailAdmin()
            );

            logService.registrarLog(
                    securityUtils.getNomeUsuarioLogado(),
                    "Provisionou nova empresa: " + empresa.getNome()
                            + " | Schema: " + empresa.getSchemaName()
            );

            return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                    "id",          empresa.getId(),
                    "nome",        empresa.getNome(),
                    "schemaName",  empresa.getSchemaName(),
                    "ativo",       empresa.getAtivo(),
                    "criadoEm",    empresa.getCriadoEm(),
                    "mensagem",    "Empresa provisionada com sucesso. "
                            + "Entregue as credenciais ao administrador."
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("erro", "Falha ao provisionar empresa: " + e.getMessage()));
        }
    }

    // ----------------------------------------------------------------
    // LISTAR TODAS AS EMPRESAS
    // ----------------------------------------------------------------
    @GetMapping
    @PreAuthorize("hasRole('MASTER')")
    public ResponseEntity<List<Empresa>> listar() {
        return ResponseEntity.ok(empresaRepository.findAll());
    }

    // ----------------------------------------------------------------
    // BUSCAR EMPRESA POR ID
    // ----------------------------------------------------------------
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('MASTER')")
    public ResponseEntity<?> buscar(@PathVariable UUID id) {
        return empresaRepository.findById(id)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Map.of("erro", "Empresa não encontrada.")));
    }

    // ----------------------------------------------------------------
    // ATIVAR / DESATIVAR EMPRESA (sem apagar dados)
    // Desativar bloqueia o login de todos os usuários da empresa
    // ----------------------------------------------------------------
    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('MASTER')")
    public ResponseEntity<?> alterarStatus(
            @PathVariable UUID id,
            @RequestBody Map<String, Boolean> payload) {

        Empresa empresa = empresaRepository.findById(id)
                .orElse(null);

        if (empresa == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("erro", "Empresa não encontrada."));
        }

        Boolean novoStatus = payload.get("ativo");
        if (novoStatus == null) {
            return ResponseEntity.badRequest()
                    .body(Map.of("erro", "Campo 'ativo' é obrigatório no corpo da requisição."));
        }

        empresa.setAtivo(novoStatus);
        empresaRepository.save(empresa);

        String acao = novoStatus
                ? "Reativou empresa: " + empresa.getNome()
                : "Desativou empresa: " + empresa.getNome();

        logService.registrarLog(securityUtils.getNomeUsuarioLogado(), acao);

        return ResponseEntity.ok(Map.of(
                "nome",    empresa.getNome(),
                "ativo",   empresa.getAtivo(),
                "mensagem", acao
        ));
    }

    // ----------------------------------------------------------------
    // REMOVER EMPRESA — IRREVERSÍVEL, apaga schema completo
    // Exige confirmação explícita no body para evitar acidentes
    // ----------------------------------------------------------------
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('MASTER')")
    public ResponseEntity<?> remover(
            @PathVariable UUID id,
            @RequestBody Map<String, String> payload) {

        // Confirmação obrigatória: body deve conter {"confirmar": "DELETAR"}
        if (!"DELETAR".equals(payload.get("confirmar"))) {
            return ResponseEntity.badRequest()
                    .body(Map.of("erro",
                            "Confirmação obrigatória. Envie {\"confirmar\": \"DELETAR\"} no body."));
        }

        Empresa empresa = empresaRepository.findById(id)
                .orElse(null);

        if (empresa == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("erro", "Empresa não encontrada."));
        }

        String nomeParaLog = empresa.getNome();
        String schemaParaLog = empresa.getSchemaName();

        try {
            provisioningService.removerTenant(empresa.getSchemaName());

            logService.registrarLog(
                    securityUtils.getNomeUsuarioLogado(),
                    "REMOVEU empresa permanentemente: " + nomeParaLog
                            + " | Schema destruído: " + schemaParaLog
            );

            return ResponseEntity.ok(Map.of(
                    "mensagem", "Empresa '" + nomeParaLog + "' e todos os seus dados foram removidos."
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("erro", "Falha ao remover empresa: " + e.getMessage()));
        }
    }

    // ----------------------------------------------------------------
    // DTO interno — evita criar arquivo separado para request simples
    // ----------------------------------------------------------------
    public static class CadastroEmpresaRequest {

        @NotBlank(message = "O nome da empresa é obrigatório")
        private String nomeEmpresa;

        @NotBlank(message = "O e-mail do administrador é obrigatório")
        @Email(message = "Formato de e-mail inválido")
        private String emailAdmin;

        public CadastroEmpresaRequest() {}

        public String getNomeEmpresa() { return nomeEmpresa; }
        public void setNomeEmpresa(String nomeEmpresa) { this.nomeEmpresa = nomeEmpresa; }

        public String getEmailAdmin() { return emailAdmin; }
        public void setEmailAdmin(String emailAdmin) { this.emailAdmin = emailAdmin; }
    }
}
