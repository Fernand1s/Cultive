package br.com.cultiva.cultivamais.multitenant;

import br.com.cultiva.cultivamais.multitenant.FuncaoUsuario; // <-- atualizado
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public class UsuarioUpdateDTO {

    @NotBlank(message = "O nome é obrigatório")
    private String nomeUsuario;

    @NotBlank(message = "O e-mail é obrigatório")
    @Email(message = "Formato de e-mail inválido")
    private String email;

    private FuncaoUsuario funcao; // agora usa o FuncaoUsuario do multitenant

    private Boolean ativo;

    public UsuarioUpdateDTO() {}

    public String getNomeUsuario() { return nomeUsuario; }
    public void setNomeUsuario(String nomeUsuario) { this.nomeUsuario = nomeUsuario; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public FuncaoUsuario getFuncao() { return funcao; }
    public void setFuncao(FuncaoUsuario funcao) { this.funcao = funcao; }

    public Boolean getAtivo() { return ativo; }
    public void setAtivo(Boolean ativo) { this.ativo = ativo; }
}
