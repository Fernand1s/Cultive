package br.com.cultiva.cultivamais.multitenant;

import br.com.cultiva.cultivamais.multitenant.Empresa;
import br.com.cultiva.cultivamais.multitenant.FuncaoUsuario;
import br.com.cultiva.cultivamais.multitenant.Usuario;
import br.com.cultiva.cultivamais.multitenant.TenantContext;
import br.com.cultiva.cultivamais.multitenant.TenantProvisioningService;
import br.com.cultiva.cultivamais.multitenant.EmpresaRepository;
import br.com.cultiva.cultivamais.multitenant.UsuarioRepository;
import br.com.cultiva.cultivamais.multitenant.UsuarioService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@Profile("dev") // SÓ roda quando você sobe com --spring.profiles.active=dev
// Nunca vai rodar em produção acidentalmente
public class DataInitializer implements CommandLineRunner {

    private final TenantProvisioningService provisioningService;
    private final EmpresaRepository empresaRepository;
    private final UsuarioRepository usuarioRepository;
    private final UsuarioService usuarioService;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(TenantProvisioningService provisioningService,
                           EmpresaRepository empresaRepository,
                           UsuarioRepository usuarioRepository,
                           UsuarioService usuarioService,
                           PasswordEncoder passwordEncoder) {
        this.provisioningService = provisioningService;
        this.empresaRepository = empresaRepository;
        this.usuarioRepository = usuarioRepository;
        this.usuarioService = usuarioService;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        System.out.println("\n========================================");
        System.out.println("  CULTIVA+ — INICIALIZANDO DADOS DE DEV");
        System.out.println("========================================\n");

        criarEmpresaSeNaoExistir(
                "Fazenda Milho X",
                "admin@milho.com",
                "Admin@1234"
        );

        criarEmpresaSeNaoExistir(
                "Fazenda Soja Y",
                "admin@soja.com",
                "Admin@1234"
        );

        System.out.println("\n========================================");
        System.out.println("  INICIALIZAÇÃO CONCLUÍDA");
        System.out.println("========================================\n");
    }

    // ----------------------------------------------------------------
    // Provisiona empresa + admin. Se já existir, pula silenciosamente.
    // ----------------------------------------------------------------
    private void criarEmpresaSeNaoExistir(String nomeEmpresa,
                                          String emailAdmin,
                                          String senhaAdmin) {
        // Verifica pelo nome se já foi provisionada antes
        if (empresaRepository.findByNome(nomeEmpresa).isPresent()) {
            System.out.println("[ SKIP ] Empresa já existe: " + nomeEmpresa);
            return;
        }

        System.out.println("[ CRIANDO ] Provisionando: " + nomeEmpresa);

        // 1. Cria schema + tabelas + registra no master
        Empresa empresa = provisioningService.provisionarNovoTenant(
                nomeEmpresa, emailAdmin);

        System.out.println("  >> Schema criado: " + empresa.getSchemaName());

        // 2. Aponta para o schema recém-criado
        TenantContext.setTenant(empresa.getSchemaName());
        try {
            // 3. Cria o usuário admin dentro do schema correto
            Usuario admin = new Usuario();
            admin.setNomeUsuario("Admin " + nomeEmpresa);
            admin.setEmail(emailAdmin);
            admin.setSenha(senhaAdmin); // UsuarioService faz o encode
            admin.setFuncao(FuncaoUsuario.ADMIN);
            admin.setAtivo(true);

            usuarioService.criarUsuario(admin);

            System.out.println("  >> Admin criado: " + emailAdmin);
            System.out.println("  >> Senha:        " + senhaAdmin);
            System.out.println("  >> Schema:       " + empresa.getSchemaName());
            System.out.println("  >> Status:       PRONTO PARA LOGIN\n");

        } finally {
            TenantContext.clear();
        }
    }
}