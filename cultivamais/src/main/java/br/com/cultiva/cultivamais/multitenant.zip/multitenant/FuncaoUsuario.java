package br.com.cultiva.cultivamais.multitenant;

public enum FuncaoUsuario {

    MASTER,       // Você — acesso ao painel interno, gerencia empresas
    ADMIN,        // Gerente da empresa contratante, gerencia funcionários
    FUNCIONARIO   // Usuário comum criado pelo gerente
}