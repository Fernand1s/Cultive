package br.com.cultiva.cultivamais.multitenant;

import br.com.cultiva.cultivamais.model.Notificacao;
import br.com.cultiva.cultivamais.model.Tarefa;
import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Entity
@Table(name = "usuario")
// ---------------------------------------------------------------
// SEM schema = "..." no @Table
// Se colocasse @Table(name = "usuario", schema = "public") o
// Hibernate ignoraria o search_path dinâmico e sempre buscaria
// no schema fixo — quebrando todo o isolamento multi-tenant.
// O schema correto é resolvido automaticamente pelo TenantContext
// via SchemaMultiTenantConnectionProvider.
// ---------------------------------------------------------------
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idUsuario;

    @Column(nullable = false)
    private String nomeUsuario;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String senha;

    @Column(nullable = false)
    private Boolean ativo = true;

    @Column(name = "codigo_recuperacao")
    private String codigoRecuperacao;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private FuncaoUsuario funcao;

    // ---------------------------------------------------------------
    // RELACIONAMENTOS
    // Mantidos exatamente como no original — funcionam normalmente
    // pois Tarefa e Notificacao também estarão no mesmo schema
    // ---------------------------------------------------------------
    @OneToMany(mappedBy = "responsavel", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Tarefa> tarefasAtribuidas;

    @OneToMany(mappedBy = "criador")
    @JsonIgnore
    private List<Tarefa> tarefasCriadas;

    @OneToMany(mappedBy = "usuario")
    @JsonIgnore
    private List<Notificacao> notificacoes;

    // ---------------------------------------------------------------
    // CONSTRUTORES
    // ---------------------------------------------------------------
    public Usuario(String nome, String email, String senha, FuncaoUsuario funcao) {
        this.nomeUsuario = nome;
        this.email = email;
        this.senha = senha;
        this.funcao = funcao;
        this.ativo = true;
    }

    public Usuario() {}

    // ---------------------------------------------------------------
    // GETTERS E SETTERS
    // ---------------------------------------------------------------
    public Long getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Long idUsuario) { this.idUsuario = idUsuario; }

    public String getNomeUsuario() { return nomeUsuario; }
    public void setNomeUsuario(String nomeUsuario) { this.nomeUsuario = nomeUsuario; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    public Boolean getAtivo() { return ativo; }
    public void setAtivo(Boolean ativo) { this.ativo = ativo; }

    public String getCodigoRecuperacao() { return codigoRecuperacao; }
    public void setCodigoRecuperacao(String codigoRecuperacao) {
        this.codigoRecuperacao = codigoRecuperacao;
    }

    public FuncaoUsuario getFuncao() { return funcao; }
    public void setFuncao(FuncaoUsuario funcao) { this.funcao = funcao; }

    public List<Tarefa> getTarefasAtribuidas() { return tarefasAtribuidas; }
    public void setTarefasAtribuidas(List<Tarefa> tarefasAtribuidas) {
        this.tarefasAtribuidas = tarefasAtribuidas;
    }

    public List<Tarefa> getTarefasCriadas() { return tarefasCriadas; }
    public void setTarefasCriadas(List<Tarefa> tarefasCriadas) {
        this.tarefasCriadas = tarefasCriadas;
    }

    public List<Notificacao> getNotificacoes() { return notificacoes; }
    public void setNotificacoes(List<Notificacao> notificacoes) {
        this.notificacoes = notificacoes;
    }
}
