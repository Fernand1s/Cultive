package br.com.cultiva.cultivamais.multitenant;

import br.com.cultiva.cultivamais.multitenant.FuncaoUsuario;
import br.com.cultiva.cultivamais.multitenant.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    Optional<Usuario> findByEmail(String email);

    List<Usuario> findByFuncao(FuncaoUsuario funcao);

    // ---------------------------------------------------------------
    // Nenhuma query precisa de schema explícito aqui.
    // O Hibernate já aplica o search_path correto antes de cada
    // consulta, graças ao SchemaMultiTenantConnectionProvider.
    //
    // Ou seja:
    // - Token da Empresa X → search_path = tenant_fazenda_milho_x
    //   → findByEmail() busca em tenant_fazenda_milho_x.usuario
    //
    // - Token da Empresa Y → search_path = tenant_fazenda_soja_y
    //   → findByEmail() busca em tenant_fazenda_soja_y.usuario
    //
    // O mesmo repositório, comportamento completamente isolado.
    // ---------------------------------------------------------------
}